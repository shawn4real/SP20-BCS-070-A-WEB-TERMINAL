import React, { useState } from "react";
import {Button} from '@material-ui/core';

const Login = () => {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const collect = () => {
    console.log(name, password);
  };

  return (
    <div className="input1">
      <h1> Log In</h1>
      <input
        className="input-box"
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="enter name"
      />

      <input
        className="input-box"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="enter password"
      />

      <button onClick={collect} className="input-button" type="button">
        Sign Up
      </button>
    </div>
  );
};
export default Login;